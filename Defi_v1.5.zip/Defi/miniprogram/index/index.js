const app = getApp()

Page({

  data: {
    motto: '这里将返回面部相似度,请等待返回值出现',
    tempFilePaths: null,
    decode:0,
    host: '74f07670f3bc9339d3c56992bb105ea0',
    addToken:0,
    userKey:0,
    grantCode:0
  },

confirm:function(){
  var key=this.data.userKey
  var stats=this.data.grantCode
  if (key == 'buptyes') {
    this.setData({
      userKey: 0,
      grantCode: 1
    })}

},
  verify:function(e)
  {
this.setData({
  userKey: e.detail.value
})
  },

  onLoad: function () {
    wx.showModal({
      title: 'FACECOMPARE',
      content: '请上传一张含有人脸的图片，对比成功则返回相似度。（图片大小请勿超过2M)，数据库导入时请谨慎!'
    })
  },

  
  //确定图片来源，从相册中选择或者是拍照
  chooseImage: function () {
    wx.showActionSheet({
      itemList: ['从相册中选择', '拍照'],
      itemColor: "#CED63A",
      success: (res) => {
        if (res.cancel) {
          return;
        }
        if (res.tapIndex == 0) {
          this.chooseWxImage('album')
        } else if (res.tapIndex == 1) {
          this.chooseWxImage('camera')
        }
      }
    })

  },
//数据库图片上传
  host:function(){
    wx.showActionSheet({
      itemList: ['从相册中选择', '拍照'],
      itemColor: "#CED63A",
      success: (res) => {
        if (res.cancel) {
          return;
        }
        if (res.tapIndex == 0) {
          this.chooseWxImage('album')
        } else if (res.tapIndex == 1) {
          this.chooseWxImage('camera')
        }
      }
    })
    
  },
//数据库图片解析
  database:function()
  {
    var code = this.data.decode
    var host = this.data.host
    var that = this

 
    wx.request({
      url: 'https://api-cn.faceplusplus.com/facepp/v3/compare?api_key=WzQDsGmIcIeYYDDdVFcbXlmOe3iIN-zU&api_secret=G1lb8puA1JUjZiILmzXdpqjQ6c9-BnlF',
      method: 'POST',
      data: {
        'face_token1': host,
        'image_base64_2': code
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res) {
         console.log(res.data)
        that.setData({
          addToken: res.data.faces2[0].face_token  //保存特征值
        })
      }
    })
  },

  dataUpload: function () {
    var code = this.data.decode
    var host = this.data.host
    var that = this
     var token=this.data.addToken

    wx.request({
      url: 'https://api-cn.faceplusplus.com/facepp/v3/faceset/addface?api_key=WzQDsGmIcIeYYDDdVFcbXlmOe3iIN-zU&api_secret=G1lb8puA1JUjZiILmzXdpqjQ6c9-BnlF',
      method: 'POST',
      data: {
        'face_tokens':token ,
        "faceset_token": "c2f21835722915a67dbe69ca8ca101c2"
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res) {
        console.log(res.data)
        // that.setData({
        //   addToken: res.data.faces2[0].face_token  //保存特征值
        // })
      }
    })
  },

dataDelete:function(){
  var that=this
  var addToken
  var code = this.data.decode
  var token = this.data.addToken
  wx.request({
    url: 'https://api-cn.faceplusplus.com/facepp/v3/faceset/removeface?api_key=WzQDsGmIcIeYYDDdVFcbXlmOe3iIN-zU&api_secret=G1lb8puA1JUjZiILmzXdpqjQ6c9-BnlF',
    method: 'POST',
    data: {
      'face_tokens': token,
      "faceset_token": "c2f21835722915a67dbe69ca8ca101c2"
    },
    header: {
      'content-type': 'application/x-www-form-urlencoded'
    },
    success(res) {
       console.log(res.data)
      // that.setData({
      //   host: res.data.faces2[0].face_token  //保存特征值
      // })
    }
  })
},
  //选择图片
  chooseWxImage: function (type) {
    var that = this
    var FSM = wx.getFileSystemManager();
    let $this = this;
    wx.chooseImage({
      sizeType: ['original', 'compressed'],
      sourceType: [type],
      success: (res) => {
        this.setData({
          tempFilePaths: res.tempFilePaths,
        })
        FSM.readFile({
          filePath: res.tempFilePaths[0],
          encoding: "base64",
          success: function (data) {
            
            that.setData({
              decode: data.data,
            })
          }
        })
      }
    })
   
  },
  

  finalCheck:function(){
    var confidence = this.data.motto
    if (confidence >= 90)
      wx.showModal({
        title: '验证成功√',
        content: `置信度为${confidence},门已开,欢迎回家！`
      })
    else if (confidence <=90 && confidence >=60)
      wx.showModal({
        title: '验证失败！',
        content: `置信度为${confidence},小于阈值,请检查照片并重试！`
      })
      else
      wx.showModal({
        title: '验证失败！',
        content: `置信度为${confidence},偏离过大,我已经报警了！`
      })
  },

  //识别图片
  identifyImage: function () {
    var that=this
   var code=this.data.decode
   var host=this.data.host
   var res=this.data.res
       wx.request({
      url: 'https://api-cn.faceplusplus.com/facepp/v3/search?api_key=WzQDsGmIcIeYYDDdVFcbXlmOe3iIN-zU&api_secret=G1lb8puA1JUjZiILmzXdpqjQ6c9-BnlF', 
      method:'POST',
      data: {
        "faceset_token": "c2f21835722915a67dbe69ca8ca101c2",
        'image_base64': code
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded' 
      },
      success(res) {
        console.log(res.data)
        that.setData({
          motto: res.data.results[0].confidence  //返回相似度
        })
       }, 
    })
    
  }
})