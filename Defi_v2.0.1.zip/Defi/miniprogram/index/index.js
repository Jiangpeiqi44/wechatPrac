const app = getApp()

Page({

  data: {
    motto: '这里将返回面部相似度,请等待返回值出现后进行下一步',
    tempFilePaths: null,
    decode: 0,
    host: '74f07670f3bc9339d3c56992bb105ea0',
    addToken: 0,
    userKey: 0,
    grantCode: 0
  },

  confirm: function () {
    var key = this.data.userKey
    var stats = this.data.grantCode
    if (key == 'buptyes') {
      this.setData({
        userKey: 0,
        grantCode: 1
      }),
        wx.showModal({
          title: '欢迎使用',
          content: '权限鉴定成功，请按照指引步骤操作数据库'
        })
    }
    else
      wx.showModal({
        title: '密码错误',
        content: '权限鉴定失败，请检查拼写或联系管理员'
      })
  },
  verify: function (e) {
    this.setData({
      userKey: e.detail.value
    })
  },

  onLoad: function () {
    wx.showModal({
      title: '使用提示',
      content: '请在充足光线下拍摄面部照片（图片大小请勿超过2M)，如设备故障请联系管理员。'
    })
  },


  //确定图片来源，从相册中选择或者是拍照
  chooseImage: function () {
    wx.showActionSheet({
      itemList: ['从相册中选择', '拍照'],
      itemColor: "#CED63A",
      success: (res) => {
        if (res.cancel) {
          return;
        }
        if (res.tapIndex == 0) {
          this.chooseWxImage('album')
        } else if (res.tapIndex == 1) {
          this.chooseWxImage('camera')
        }
      }
    })

  },
  //数据库图片上传
  host: function () {
    wx.showActionSheet({
      itemList: ['从相册中选择', '拍照'],
      itemColor: "#CED63A",
      success: (res) => {
        if (res.cancel) {
          return;
        }
        if (res.tapIndex == 0) {
          this.chooseWxImage('album')
        } else if (res.tapIndex == 1) {
          this.chooseWxImage('camera')
        }
      }
    })

  },
  //数据库图片解析
  database: function () {
    var code = this.data.decode
    var host = this.data.host
    var that = this


    wx.request({
      url: 'https://api-cn.faceplusplus.com/facepp/v3/compare?api_key=WzQDsGmIcIeYYDDdVFcbXlmOe3iIN-zU&api_secret=G1lb8puA1JUjZiILmzXdpqjQ6c9-BnlF',
      method: 'POST',
      data: {
        'face_token1': host,
        'image_base64_2': code
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res) {
        console.log(res.data)
        that.setData({
          addToken: res.data.faces2[0].face_token  //保存特征值
        })
      }
    })
  },

  dataUpload: function () {
    var code = this.data.decode
    var host = this.data.host
    var that = this
    var token = this.data.addToken

    wx.request({
      url: 'https://api-cn.faceplusplus.com/facepp/v3/faceset/addface?api_key=WzQDsGmIcIeYYDDdVFcbXlmOe3iIN-zU&api_secret=G1lb8puA1JUjZiILmzXdpqjQ6c9-BnlF',
      method: 'POST',
      data: {
        'face_tokens': token,
        "faceset_token": "c2f21835722915a67dbe69ca8ca101c2"
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res) {
        console.log(res.data)
        // that.setData({
        //   addToken: res.data.faces2[0].face_token  //保存特征值
        // })
      }
    })
  },

  dataDelete: function () {
    var that = this
    var addToken
    var code = this.data.decode
    var token = this.data.addToken
    wx.request({
      url: 'https://api-cn.faceplusplus.com/facepp/v3/faceset/removeface?api_key=WzQDsGmIcIeYYDDdVFcbXlmOe3iIN-zU&api_secret=G1lb8puA1JUjZiILmzXdpqjQ6c9-BnlF',
      method: 'POST',
      data: {
        'face_tokens': token,
        "faceset_token": "c2f21835722915a67dbe69ca8ca101c2"
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res) {
        console.log(res.data)
        // that.setData({
        //   host: res.data.faces2[0].face_token  //保存特征值
        // })
      }
    })
  },
  //选择图片
  chooseWxImage: function (type) {
    var that = this
    var FSM = wx.getFileSystemManager();
    let $this = this;
    wx.chooseImage({
      sizeType: ['original', 'compressed'],
      sourceType: [type],
      success: (res) => {
        this.setData({
          tempFilePaths: res.tempFilePaths,
        })
        FSM.readFile({
          filePath: res.tempFilePaths[0],
          encoding: "base64",
          success: function (data) {

            that.setData({
              decode: data.data,
            })
          }
        })
      }
    })

  },

openDoor:function(){
var confidence=this.data.motto
if(confidence>=90){
  wx.request({
    url: 'http://api.heclouds.com/devices/562080954/datapoints',
    header: {
      'content-type': 'application/json',
      'api-key': '=mqY=mf4Nwi7FzME=QlBsjDXedU='
    },
    method: 'POST',
    data: {
      "datastreams": [{
        "id": "doorStatus",
        "datapoints":
          [{
            "value": "OPEN"
          }]

      }]
    },
    success(res) {
      console.log(res.data)

    }
  })
}

  else if(confidence<=60){
    wx.request({
      url: 'http://api.heclouds.com/devices/562080954/datapoints',
      header: {
        'content-type': 'application/json',
        'api-key': '=mqY=mf4Nwi7FzME=QlBsjDXedU='
      },
      method: 'POST',
      data: {
        "datastreams": [{
          "id": "doorStatus",
          "datapoints":
            [{
              "value": "RETRY"
            }]

        }]
      },
      success(res) {
        console.log(res.data)

      }
    })
  }

else
{
  wx.request({
    url: 'http://api.heclouds.com/devices/562080954/datapoints',
    header: {
      'content-type': 'application/json',
      'api-key': '=mqY=mf4Nwi7FzME=QlBsjDXedU='
    },
    method: 'POST',
    data: {
      "datastreams": [{
        "id": "doorStatus",
        "datapoints":
          [{
            "value": "ALERT"
          }]

      }]
    },
    success(res) {
      console.log(res.data)

    }
  })
}
  if (confidence >= 90)
    wx.showModal({
      title: '芝麻开门！',
      content: '门已开',
    })
  else
    wx.showModal({
      title: '未通过鉴权！',
      content: '想进？没门！',
    })
},
  finalCheck: function () {
    var confidence = this.data.motto
    if (confidence >= 90) {
      wx.showModal({
        title: '验证成功√',
        content: `置信度为${confidence},已验明真身,欢迎回家！`
      })
      
    }
    else if (confidence <= 90 && confidence >= 60) {
      wx.showModal({
        title: '验证失败！',
        content: `置信度为${confidence},小于阈值,请检查照片并重试！`
      })
    }
    else {
      wx.showModal({
        title: '验证失败！',
        content: `置信度为${confidence},偏离过大,我已经报警了！`
      })
    }
  },

  //识别图片
  identifyImage: function () {
    var that = this
    var code = this.data.decode
    var host = this.data.host
    var res = this.data.res
    wx.request({
      url: 'https://api-cn.faceplusplus.com/facepp/v3/search?api_key=WzQDsGmIcIeYYDDdVFcbXlmOe3iIN-zU&api_secret=G1lb8puA1JUjZiILmzXdpqjQ6c9-BnlF',
      method: 'POST',
      data: {
        "faceset_token": "c2f21835722915a67dbe69ca8ca101c2",
        'image_base64': code
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res) {
        console.log(res.data)
        that.setData({
          motto: res.data.results[0].confidence  //返回相似度
        })
      },
    })

  }
})